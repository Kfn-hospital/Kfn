'use client';

import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import Card from '@/components/ui/Card';
import DataTable from '@/components/ui/DataTable';
import type { Profile, UserRole } from '@/types/database';

type Tab = 'regular' | 'admins';

const ADMIN_ROLES: UserRole[] = ['admin', 'room_manager', 'coordinator', 'coordination_admin'];
const ALWAYS_CAN_UPLOAD_ROLES: UserRole[] = ['admin', 'coordination_admin'];

export default function UsersPage() {
  const supabase = createClient();
  const router = useRouter();
  const { t } = useLanguage();
  const [users, setUsers] = useState<Profile[]>([]);
  const [uploaderIds, setUploaderIds] = useState<Set<string>>(new Set());
  const [tab, setTab] = useState<Tab>('regular');
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [authorized, setAuthorized] = useState(false);
  const [search, setSearch] = useState('');

  useEffect(() => {
    (async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) {
        router.push('/login');
        return;
      }
      const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single();
      if (profile?.role !== 'admin') {
        router.push('/dashboard');
        return;
      }
      setAuthorized(true);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadUsers() {
    // الأحدث (اللي انضم مؤخرًا) يظهر فوق، لأن عدد الموظفين بقى كبير
    // وأسهل حاجة للأدمن إنه يلاقي الحساب اللي لسه مضاف.
    const { data } = await supabase.from('profiles').select('*').order('created_at', { ascending: false });
    setUsers((data as Profile[]) || []);

    const { data: uploaders } = await supabase.from('file_uploaders').select('user_id');
    setUploaderIds(new Set(((uploaders as { user_id: string }[] | null) ?? []).map((r) => r.user_id)));
  }

  useEffect(() => {
    if (authorized) loadUsers();
  }, [authorized]);

  async function toggleUploader(id: string, current: boolean) {
    setUploaderIds((prev) => {
      const next = new Set(prev);
      if (current) next.delete(id);
      else next.add(id);
      return next;
    });
    if (current) {
      await supabase.from('file_uploaders').delete().eq('user_id', id);
    } else {
      await supabase.from('file_uploaders').upsert({ user_id: id });
    }
  }

  async function updateRole(id: string, role: UserRole) {
    await supabase.from('profiles').update({ role }).eq('id', id);
    loadUsers();
  }

  async function activateUser(id: string) {
    await supabase.from('profiles').update({ status: 'active' }).eq('id', id);
    loadUsers();
  }

  async function toggleStatus(id: string, current: string) {
    await supabase
      .from('profiles')
      .update({ status: current === 'active' ? 'suspended' : 'active' })
      .eq('id', id);
    loadUsers();
  }

  async function deleteUser(id: string) {
    if (!window.confirm(t('confirmDeleteUser'))) return;
    setDeletingId(id);
    try {
      const res = await fetch('/api/admin/delete-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: id }),
      });
      const json = await res.json();
      if (json.ok) {
        loadUsers();
      } else {
        alert(json.error || t('errorOccurred'));
      }
    } catch (err) {
      alert(err instanceof Error ? err.message : String(err));
    } finally {
      setDeletingId(null);
    }
  }

  const roleLabel: Record<string, string> = {
    admin: t('roleAdmin'),
    room_manager: t('roleRoomManager'),
    coordinator: t('roleCoordinator'),
    coordination_admin: t('roleCoordinationAdmin'),
    employee: t('roleEmployee'),
  };

  const searchedUsers = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return users;
    return users.filter((u) =>
      [u.name, u.email, u.department, u.phone].some((field) => (field || '').toLowerCase().includes(q))
    );
  }, [users, search]);

  const regularUsers = useMemo(() => searchedUsers.filter((u) => u.role === 'employee'), [searchedUsers]);
  const adminUsers = useMemo(
    () => searchedUsers.filter((u) => ADMIN_ROLES.includes(u.role as UserRole)),
    [searchedUsers]
  );
  const pendingCount = useMemo(() => users.filter((u) => u.status === 'pending').length, [users]);

  const renderStatus = (u: Profile) => {
    if (u.status === 'pending') {
      return (
        <div className="flex items-center gap-2">
          <span className="px-2 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-700">
            {t('pendingApproval')}
          </span>
          <button
            onClick={() => activateUser(u.id)}
            className="px-2 py-1 rounded-full text-xs font-bold bg-[var(--c-teal-700)] text-white"
          >
            {t('activate')}
          </button>
        </div>
      );
    }
    return (
      <button
        onClick={() => toggleStatus(u.id, u.status)}
        className={`px-2 py-1 rounded-full text-xs font-bold ${
          u.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
        }`}
      >
        {u.status === 'active' ? t('active') : t('inactive')}
      </button>
    );
  };

  const columns = [
    { header: t('name'), render: (u: Profile) => u.name },
    { header: 'Email', render: (u: Profile) => u.email },
    { header: t('signupPhone'), render: (u: Profile) => u.phone || '-' },
    { header: t('userDepartment'), render: (u: Profile) => u.department || '-' },
    {
      header: t('userRole'),
      render: (u: Profile) => (
        <select
          value={u.role}
          onChange={(e) => updateRole(u.id, e.target.value as UserRole)}
          className="border rounded-lg px-2 py-1 text-sm"
        >
          {Object.entries(roleLabel).map(([val, label]) => (
            <option key={val} value={val}>
              {label}
            </option>
          ))}
        </select>
      ),
    },
    { header: t('status'), render: renderStatus },
    {
      header: t('canUploadFiles'),
      render: (u: Profile) => {
        const forced = ALWAYS_CAN_UPLOAD_ROLES.includes(u.role as UserRole);
        const checked = forced || uploaderIds.has(u.id);
        return (
          <label className="flex items-center justify-center" title={forced ? t('canUploadFilesForced') : ''}>
            <input
              type="checkbox"
              checked={checked}
              disabled={forced}
              onChange={() => toggleUploader(u.id, uploaderIds.has(u.id))}
              className="w-4 h-4"
            />
          </label>
        );
      },
    },
    {
      header: t('actions'),
      render: (u: Profile) => (
        <div className="flex items-center gap-2">
          <Link href={`/admin/users/${u.id}/edit`} className="text-[var(--c-teal-600)] text-xs font-bold hover:underline">
            {t('edit')}
          </Link>
          <button
            type="button"
            onClick={() => deleteUser(u.id)}
            disabled={deletingId === u.id}
            className="text-red-600 text-xs font-bold hover:underline disabled:opacity-50"
          >
            {t('delete')}
          </button>
        </div>
      ),
    },
  ];

  if (!authorized) return null;

  return (
    <main className="p-6">
      <div className="flex items-center justify-between flex-wrap gap-3 mb-6">
        <h1 className="text-2xl font-extrabold text-[var(--c-teal-900)]">{t('usersTitle')}</h1>
        <Link
          href="/admin/users/new"
          className="bg-[var(--c-teal-700)] text-white rounded-xl px-5 py-2.5 font-bold text-sm"
        >
          ➕ {t('addUser')}
        </Link>
      </div>

      <div className="mb-4">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={t('usersSearchPlaceholder')}
          className="w-full sm:max-w-sm border rounded-xl px-3 py-2.5"
        />
      </div>

      <div className="flex flex-wrap gap-2 mb-4">
        <button
          onClick={() => setTab('regular')}
          className={`px-4 py-2 rounded-xl text-sm font-bold ${
            tab === 'regular' ? 'bg-[var(--c-teal-700)] text-white' : 'bg-[var(--c-surface)] text-[var(--c-text)]'
          }`}
        >
          {t('usersTabRegular')} {pendingCount > 0 && `(${pendingCount} ${t('pendingApproval')})`}
        </button>
        <button
          onClick={() => setTab('admins')}
          className={`px-4 py-2 rounded-xl text-sm font-bold ${
            tab === 'admins' ? 'bg-[var(--c-teal-700)] text-white' : 'bg-[var(--c-surface)] text-[var(--c-text)]'
          }`}
        >
          {t('usersTabAdmins')}
        </button>
      </div>

      <Card>
        <DataTable
          emptyMessage={t('noData')}
          rows={tab === 'regular' ? regularUsers : adminUsers}
          columns={columns}
        />
      </Card>
    </main>
  );
}
